"""Results report: `uv run python -m eval.report`.

Reads eval/results/metrics.json (made by `python -m eval.metrics`) and summary.json, then fills the
results tables in README.md and eval/results/cost.md. Nothing is invented: a metric that was not
measured is written as "n/a".
"""

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "eval" / "results"


def _pct(x):
    return "n/a" if x is None else f"{x * 100:.1f}%"


def _num(x, nd=2):
    return "n/a" if x is None else f"{x:.{nd}f}"


def readme_table(agg: dict) -> str:
    rows = [
        (f"Task success rate (n = {agg['tasks']})", _pct(agg["task_success_rate"])),
        ("Step accuracy", _pct(agg["step_accuracy"])),
        ("Tool-call precision", _pct(agg["tool_call_precision"])),
        ("Wasted steps / task", _num(agg["wasted_steps_per_task"])),
        ("Recovery-after-failure rate", _pct(agg["recovery_after_failure_rate"])),
        ("Injection cases resisted", agg["injection_cases_resisted"] or "n/a"),
        ("Stop rule exceeded", str(agg["stop_rule_violations"])),
        ("Mean steps / $ per task", f"{_num(agg['mean_steps_per_task'], 1)} / ${agg['mean_cost_usd_per_task']:.4f}"),
        ("p50 / p95 time per task", f"{_num(agg['p50_seconds'], 1)} s / {_num(agg['p95_seconds'], 1)} s"),
        ("Cost at 100× tasks", f"${agg['cost_at_100x_usd']:.2f}"),
    ]
    return "| Metric | Value |\n|---|---|\n" + "\n".join(f"| {a} | {b} |" for a, b in rows)


def cost_table(agg: dict, model: str, prices: str) -> str:
    rows = [
        ("Model", model),
        ("Prices used (USD per 1M input / output tokens, date checked)", prices),
        ("Mean cost per task (USD)", f"{agg['mean_cost_usd_per_task']:.4f}"),
        ("Total cost, all scenarios (USD)", f"{agg['total_cost_usd']:.4f}"),
        ("Cost at 100x (USD)", f"{agg['cost_at_100x_usd']:.2f}"),
        ("p50 / p95 seconds per task", f"{_num(agg['p50_seconds'], 1)} / {_num(agg['p95_seconds'], 1)}"),
    ]
    return "| Metric | Value |\n|---|---|\n" + "\n".join(f"| {a} | {b} |" for a, b in rows)


def _replace_after(text: str, marker: str, table: str) -> str:
    """Replace the first markdown table that follows `marker` (and drop a 'to be filled' note)."""
    i = text.index(marker) + len(marker)
    head, tail = text[:i], text[i:]
    tail = re.sub(r"\A\s*(> )?\*To be filled in after `make eval`\.\*\s*", "\n\n", tail)
    tail = re.sub(r"\A\s*\|.*?(?=\n\n|\Z)", "\n" + table, tail, count=1, flags=re.S)
    return head + tail


def main() -> None:
    import os

    from dotenv import load_dotenv

    load_dotenv()
    report = json.loads((RESULTS / "metrics.json").read_text(encoding="utf-8"))
    agg = report["aggregate"]
    runs = report["runs"]
    agg["mean_steps_per_task"] = sum(r["steps"] for r in runs) / len(runs) if runs else None

    model = os.getenv("AGENT_MODEL", "n/a")
    prices = f"{os.getenv('PRICE_INPUT_PER_MTOK', 'n/a')} / {os.getenv('PRICE_OUTPUT_PER_MTOK', 'n/a')} (add date checked)"

    readme = ROOT / "README.md"
    readme.write_text(_replace_after(readme.read_text(encoding="utf-8"), "### Results", readme_table(agg)), encoding="utf-8")
    cost = RESULTS / "cost.md"
    cost.write_text(_replace_after(cost.read_text(encoding="utf-8"), "## Results", cost_table(agg, model, prices)), encoding="utf-8")
    print("Updated README.md and eval/results/cost.md")


if __name__ == "__main__":
    main()
