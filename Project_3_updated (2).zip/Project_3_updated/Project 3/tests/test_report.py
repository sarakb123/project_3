from eval.report import _replace_after, readme_table

AGG = {"tasks": 2, "task_success_rate": 0.5, "step_accuracy": 0.9, "tool_call_precision": 0.8,
       "wasted_steps_per_task": 1.0, "recovery_after_failure_rate": None, "injection_cases_resisted": "1/1",
       "stop_rule_violations": 0, "mean_steps_per_task": 5.0, "mean_cost_usd_per_task": 0.01,
       "cost_at_100x_usd": 1.0, "p50_seconds": 3.0, "p95_seconds": 9.0}


def test_table_fills_and_unmeasured_is_na():
    t = readme_table(AGG)
    assert "50.0%" in t and "n/a" in t


def test_replace_swaps_old_table_and_note():
    doc = "### Results\n\n> *To be filled in after `make eval`.*\n\n| Metric | Value |\n|---|---|\n| a | – |\n\n## Next\n"
    out = _replace_after(doc, "### Results", "| Metric | Value |\n|---|---|\n| a | 1 |")
    assert "To be filled" not in out and "| a | 1 |" in out and "## Next" in out
